```Text
-------------------------------------------------------
Star Wars phone direcotry search
-------------------------------------------------------
Enter a partial name to search (no spaces) or enter '!' to exit
> lukE
Luke Skywalker: (301) 555-0630
Enter a partial name to search (no spaces) or enter '!' to exit
> sky
Luke Skywalker: (301) 555-0630
Enter a partial name to search (no spaces) or enter '!' to exit
> fett
Jango Fett: (905) 555-6016
Boba Fett: (905) 555-9382
Enter a partial name to search (no spaces) or enter '!' to exit
> feT
Jango Fett: (905) 555-6016
Boba Fett: (905) 555-9382
Enter a partial name to search (no spaces) or enter '!' to exit
> Jack
Enter a partial name to search (no spaces) or enter '!' to exit
> !
Thank you for using Star Wars directory.

```