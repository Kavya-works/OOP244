
/******************************************************************************
					Workshop - #1 (Part-2)
Full Name :Kavya Bhavinkumar Shah
Student ID#:140055229
Email : kbshah6@myseneca.ca
Section : ZCC
Authenticity Declaration:
I declare this submission is the result of my own work and has not been
shared with any other student or 3rd party content provider. This submitted
piece of work is entirely of my own creation.
******************************************************************************/
#pragma once
#ifndef SDDS_cStrTools_H
#define SDDS_cStrTools_H
namespace sdds {


	char toLower(char ch);
	int strCmp(const char* s1, const char* s2);
	int strnCmp(const char* s1, const char* s2, int len);
	void strCpy(char* des, const char* src);
	int strLen(const char* str);
	const char* strStr(const char* str, const char* find);
	int isAlpha(char ch);
	int isSpace(char ch);
	void trim(char word[]);
	void toLowerCaseAndCopy(char des[], const char source[]);
}
#endif // !SDDS_CSTRTOOLS_H
