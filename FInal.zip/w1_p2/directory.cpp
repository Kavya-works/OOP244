/***********************************************************************
// OOP244 Workshop #1 DIY: tester program
//
// File  direcotry.cpp
// Version 1.0
// Author   Fardad Soleimanloo
// Description
//
// Revision History
// -----------------------------------------------------------
// Name            Date            Reason
***********************************************************************/
#include "Phone.h"
using namespace sdds;
int main() {
   phoneDir("Star Wars", "phones.txt");
   return 0;
}