/* Name: Kavya Shah
   Student ID: 140055229
   Email: kbshah6@myseneca.ca */

#ifndef SDDS_UTILS_H
#define SDDS_UTILS_H

#include <iostream>

namespace sdds {
    void clearBuffer();
    int getInt();
}

#endif
