/* Name: Kavya Shah
   Student ID: 140055229
   Email: kbshah6@myseneca.ca */

#include "Utils.h"

namespace sdds {
    void clearBuffer() {
       
        std::cin.clear();
        std::cin.ignore(1000, '\n');
    }

    int getInt() {
        int value;
        bool validInput = false;

        do {
            
            std::cin >> value;

            if (std::cin.fail()) {
               
                std::cout << "Invalid integer, please try again: ";
                clearBuffer();
            }
            else {
                validInput = true;
            }
        } while (!validInput);

        return value;
    }
}
