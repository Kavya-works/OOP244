/***********************************************************************
 Workshop - #3 (P1)

Full Name :Kavya Shah
Student ID#:140055229
Email :kbshah6@myseneca.ca
Section :ZCC
Date :2023-09-28
Authenticity Declaration:
I have done all the coding by myself and only copied the code that my professor provided to complete my workshops and assignments.
***********************************************************************/
#ifndef TRAIN_H
#define TRAIN_H

namespace sdds {
    const int MIN_TIME = 700;
    const int MAX_TIME = 2300;
    const int MAX_NO_OF_PASSENGERS = 1000;

    class Train {
        char* name;
        int passengers;
        int departureTime;

    public:
        Train();
        ~Train();
        void initialize();
        bool validTime(int value) const;
        bool validNoOfPassengers(int value) const;
        void set(const char* name);
        void set(int noOfPassengers, int departure);
        void set(const char* name, int noOfPassengers, int departure);
        void finalize();
        bool isInvalid() const;
        int noOfPassengers() const;
        const char* getName() const;
        int getDepartureTime() const;
        void display() const;
    };
}

#endif // TRAIN_H
