/***********************************************************************
// Final project Milestone 2
// Module: Menu and AidMan
// File: Menu.h
// Version 1.0
// Author  Fardad Soleimanloo
// Description
//
// Revision History
// --------------------------------------------------------------------
// Name: Kavya Shah                 Date: 11-15-2023            Reason
***********************************************************************/

#ifndef MENU_H
#define MENU_H

namespace sdds {

    class Menu {
    private:
        char* menuContent;
        unsigned int numOptions;

    public:
        Menu(const char* content);
        ~Menu();
        Menu(const Menu&) = delete;
        Menu& operator=(const Menu&) = delete;

        unsigned int run();
    };
}
#endif