/***********************************************************************
// Final project Milestone 2
// Module: Menu and AidMan
// File: AidMan.h
// Version 1.0
// Author  Fardad Soleimanloo
// Description
//
// Revision History
// --------------------------------------------------------------------
// Name: Kavya Shah                 Date: 11-15-2023            Reason
***********************************************************************/

#ifndef AIDMAN_H
#define AIDMAN_H
#include "Menu.h"

namespace sdds {
	class AidMan {

		char* filename;
		Menu mainMenu;
	public:
		AidMan(const char* fileName);
		~AidMan();
		AidMan(const AidMan&) = delete;
		AidMan& operator=(const AidMan) = delete;

		void run();

	private:
		unsigned int menu();
	};
}
#endif