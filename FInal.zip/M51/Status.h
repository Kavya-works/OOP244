/**********************************************************************************
					
Name		   - Kavya Bhavinkumar Shah
Student ID#        - 140055229
Email		   - kbshah6@myseneca.ca
Section		   - ZCC
Date of Completion - 02/12/2023

I have done all the work on my own. I only used the files provided by the professor.
***********************************************************************************/

#ifndef SDDS_STATUS_H
#define SDDS_STATUS_H
#include <iostream>
namespace sdds {
	class Status {
		char* description{};
		int statusCode{};
	public:
		Status() {}
		Status(char* desc, int status);
		~Status();
		Status(const Status& other);
		void setStatus(int status);
		void setStatus(const char* status);
		int getStatus() const;
		const char* getDescription()const;
		operator int() const;
		operator const char* () const;
		operator bool() const;
	        Status& operator=(const char* newDesc);
		Status& operator=(const int newStatus);
		Status& clear();

	};

	std::ostream& operator <<(std::ostream& ostr, const Status& status);
}
#endif 