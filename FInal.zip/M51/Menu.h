/**********************************************************************************
					
Name		   - Kavya Bhavinkumar Shah
Student ID#        - 140055229
Email		   - kbshah6@myseneca.ca
Section		   - ZCC
Date of Completion - 02/12/2023

I have done all the work on my own. I only used the files provided by the professor.
***********************************************************************************/

#ifndef SDDS_MENU_H
#define SDDS_MENU_H
#include<iostream>
namespace sdds {
	class Menu {
		char* m_options;


	public:
		Menu(const char* options);
		unsigned int run() const;
		~Menu();
	};
}
#endif 