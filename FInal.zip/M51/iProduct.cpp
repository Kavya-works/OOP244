/**********************************************************************************
					
Name		   - Kavya Bhavinkumar Shah
Student ID#        - 140055229
Email		   - kbshah6@myseneca.ca
Section		   - ZCC
Date of Completion - 02/12/2023

I have done all the work on my own. I only used the files provided by the professor.
***********************************************************************************/


#include "iProduct.h"

namespace sdds {
	std::istream& operator>>(std::istream& istr, iProduct& p) {
		return p.read(istr);
	}
	std::ostream& operator<<(std::ostream& ostr, iProduct& p) {
		return p.display(ostr);
	}
}