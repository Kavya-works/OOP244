/**********************************************************************************
					
Name		   - Kavya Bhavinkumar Shah
Student ID#        - 140055229
Email		   - kbshah6@myseneca.ca
Section		   - ZCC
Date of Completion - 02/12/2023

I have done all the work on my own. I only used the files provided by the professor.
***********************************************************************************/


#ifndef SDDS_UTILS_H
#define SDDS_UTILS_H
#include<iostream>
namespace sdds {
       const int sdds_testYear = 2023;
    const int sdds_testMon = 10;
    const int sdds_testDay = 9;

    class Utils {

        bool m_testMode = false;

    public:
                void getSystemDate(int* year = nullptr, int* mon = nullptr, int* day = nullptr);
                int daysOfMon(int mon, int year)const;
               void testMode(bool testmode = true);
                void alocpy(char*& destination, char* source);
                int getint(int min, int max, const char* prompt = nullptr, const char* errMes = nullptr);

    };

    extern Utils ut; 
}

#endif 
