/*Full Name             : Kavya Bhavinkumar Shah                           
Student ID#             : 140055229                           
Email                   : kbshah6@myseneca.ca                         
Section                 : ZCC                                                                                
                                                                            
I have done all the coding by myself and only copied the code               
provided by the professor to complete my workshops and assignments.*/

#ifndef SDDS_GRADUATE_H
#define SDDS_GRADUATE_H

#include"Student.h"
/// <summary>
/// this ia class which inherit from the Student class and hold the name of the supervisor and title of the thesis for this Graduate student dynamically.
/// three construcotrs - default constructor,parameterized and copy constructor 
/// two private methods to set the thesis style and supervisor name 
/// </summary>
namespace sdds {
    class Graduate : public Student
    {
        char* m_supervisor;
        char* m_thesisTitle;

        //Private methods
        void setThesisTitle(const char* thesisTitle);
        void setSupervisor(const char* supervisor);

        void clear();
    public:
        Graduate();
        Graduate(const char* name, int age, const char* supervisor, const char* thesisTitle);


        Graduate(const Graduate& src);
        Graduate& operator=(const Graduate& src);
        ~Graduate();

        void display() const;
    };
}
#endif // !SDDS_GRADUATE_H