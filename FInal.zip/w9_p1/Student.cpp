/*Full Name             : Kavya Bhavinkumar Shah
Student ID#             : 140055229
Email                   : kbshah6@myseneca.ca
Section                 : ZCC

I have done all the coding by myself and only copied the code
provided by the professor to complete my workshops and assignments.*/

#define _CRT_SECURE_NO_WARNINGS

#include<iostream>
#include<cstring>
#include"Student.h"

using namespace std;
namespace sdds {
    // this function will intialize the name of university students by intializing it with nullptr and age of the students to zero
    void Student::clear()
    {
        m_name = nullptr;
        m_age = 0;
    }
    // this function will first clear the data in the name by using delete keyword 
    // after this it will dynamically allocate the name of the university students and 
    void Student::setName(const char* name)
    {
        if (m_name != nullptr)
        {
            delete[] m_name;
            clear();
        }

        if (name != nullptr)
        {
            m_name = new char[strlen(name) + 1];
            strcpy(m_name, name);
        }
        else
        {
            clear();
        }
    }
    /// <summary>
    ///  default constructor which will set the object to a safe empty state. 
    /// </summary>
    Student::Student()
    {
        clear(); // this will call clear function 
    }
    // it is an parameterized constructor which will  receives the name and the age of the student. A copy of the name is dynamically held by the name pointer in the class and the age attribute is set to the age argument.
    Student::Student(const char* name, int age)
    {
        clear();
        setName(name);
        m_age = age;
    }
    /// <summary>
    /// this is a copy constructor which recives another object which will then deep copy data from current object to another object src
    /// </summary>
    /// <param name="src"></param>
    Student::Student(const Student& src)
    {
        clear();
        *this = src;
    }
    /// <summary>
    /// this is a copy assigment operator which will copy data of one object data into another one following the rule of three  
    /// </summary>
    /// <param name="src"></param>
    /// <returns> current object </returns>
    Student& Student::operator=(const Student& src)
    {
        if (this != &src) // self-asssigment 
        {
            setName(src.m_name);
            m_age = src.m_age;
        }
        else
        {
            clear();
        }

        return *this;
    }
    // destructor this will ensure there is no memory leak 
    Student::~Student()
    {
        delete[] m_name;
        clear();
    }
    /// <summary>
    /// This method simply displays the name and age of the student along with the Thesis title and name of the supervisor
    /// </summary>
    void Student::display() const
    {
        if (m_name != nullptr && m_age > 0)
        {
            cout << "Name: " << m_name << endl;
            cout << "Age: " << m_age << endl;
        }
    }
}