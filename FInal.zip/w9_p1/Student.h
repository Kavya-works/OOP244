/*Full Name             : Kavya Bhavinkumar Shah
Student ID#             : 140055229
Email                   : kbshah6@myseneca.ca
Section                 : ZCC

I have done all the coding by myself and only copied the code
provided by the professor to complete my workshops and assignments.*/

#ifndef SDDS_STUDENT_H
#define SDDS_STUDENT_H
/// <summary>
/// this class contains two private variable in which m_name is dynamically array
/// three construcotrs : default constructor, one copy constructor, parameterized constructor  
///  copy assigment operator 
///  virtual destructor 
/// </summary>
namespace sdds {
    class Student
    {
        char* m_name;
        int m_age;

        // Private methods
        void clear();
        void setName(const char* name);
    public:
        Student();
        Student(const char* name, int age);

        // i implemented rule of three so the memory is managed properly 
        Student(const Student& src);
        Student& operator=(const Student& src);
        virtual ~Student();

        void display() const;
    };
}
#endif // !SDDS_STUDENT_H
