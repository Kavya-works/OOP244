/**********************************************************************************
                                   
Name		       - Kavya Shah
Student ID#        - 140055229
Email			   - kbshah6@myseneca.ca
Section			   - ZCC
Date of Completion - 19-11-2023

I have done all the work on my own. I only used the files provided by the professor.
***********************************************************************************/

// Shape.cpp

#include "Shape.h"

namespace sdds
{
    std::istream& operator>>(std::istream& is, Shape& src)
    {
        src.getSpecs(is);
        return is;
    }

    std::ostream& operator<<(std::ostream& os, const Shape& src)
    {
        src.draw(os);
        return os;
    }
}
