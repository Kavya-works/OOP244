/**********************************************************************************
                                   
Name		       - Kavya Shah
Student ID#        - 140055229
Email			   - kbshah6@myseneca.ca
Section			   - ZCC
Date of Completion - 19-11-2023

I have done all the work on my own. I only used the files provided by the professor.
***********************************************************************************/


#define _CRT_SECURE_NO_WARNINGS

#include <iostream>
#include <cstring>
#include <string>

#include "LblShape.h"


using namespace std;

namespace sdds
{
    const char* LblShape::label() const
    {
        return m_label;
    }

    LblShape::LblShape(const char* label)
    {
        if (label && label[0] != '\0')
        {
            m_label = new char[strlen(label) + 1];
            strcpy(m_label, label);
        }
    }

    LblShape::~LblShape()
    {
        if (m_label)
        {
            delete[] m_label;
            m_label = nullptr;
        }
    }

    void LblShape::getSpecs(std::istream& is)
    {
        delete[] m_label;
        string label;

        getline(is, label, ',');
        m_label = new char[strlen(label.c_str()) + 1];
        strcpy(m_label, label.c_str());
    }
}