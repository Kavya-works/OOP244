/**********************************************************************************
                                   
Name		       - Kavya Shah
Student ID#        - 140055229
Email			   - kbshah6@myseneca.ca
Section			   - ZCC
Date of Completion - 19-11-2023

I have done all the work on my own. I only used the files provided by the professor.
***********************************************************************************/

#ifndef SDDS_SHAPE_H_
#define SDDS_SHAPE_H_

#include <iostream>

namespace sdds
{
    class Shape
    {
    public:
        virtual ~Shape() {}
        virtual void draw(std::ostream& os) const = 0;
        virtual void getSpecs(std::istream& is) = 0;
    };

    std::ostream& operator<<(std::ostream& os, const Shape& src);
    std::istream& operator>>(std::istream& is, Shape& src);
}

#endif