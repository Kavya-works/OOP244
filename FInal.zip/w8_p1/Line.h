/**********************************************************************************
                                    
Name		       - Kavya Shah
Student ID#        - 140055229
Email			   - kbshah6@myseneca.ca
Section			   - ZCC
Date of Completion - 19-11-2023

I have done all the work on my own. I only used the files provided by the professor.
***********************************************************************************/


#ifndef SDDS_LINE_H_
#define SDDS_LINE_H_

#include "LblShape.h"

namespace sdds
{
    class Line : public LblShape
    {
        unsigned int m_length{ 0 };
    public:
        Line() {}
        Line(const char* label, int length);
        virtual ~Line() {}

        void getSpecs(std::istream& is);
        void draw(std::ostream& os) const;
    };
}
#endif