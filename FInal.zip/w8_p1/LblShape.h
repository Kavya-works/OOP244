/**********************************************************************************
                                   
Name		       - Kavya Shah
Student ID#        - 140055229
Email			   - kbshah6@myseneca.ca
Section			   - ZCC
Date of Completion - 19-11-2023

I have done all the work on my own. I only used the files provided by the professor.
***********************************************************************************/


#ifndef SDDS_Lblshape_H_
#define SDDS_Lblshape_H_

#include "Shape.h"

namespace sdds
{
    class LblShape : public Shape
    {
        char* m_label = nullptr;
    protected:
        const char* label() const;
    public:
        LblShape() {}
        LblShape(const char* label);
        virtual ~LblShape();
        void getSpecs(std::istream& is);

        LblShape(const LblShape& src) = delete;
        LblShape& operator=(const LblShape& src) = delete;

    };
}
#endif