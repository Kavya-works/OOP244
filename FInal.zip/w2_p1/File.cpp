/*
Name: Kavya Bhavinkumar Shah
Number: 140055229
Section: ZCC
I have done all the coding by myself and only copied the code that my professor provided to complete my workshops and assignments.
*/

/***********************************************************************
// OOP244 Workshop #2 lab (part 1)
//
// File  File.cpp
// Version 1.0
// Author   Fardad Soleimanloo
// Description
//    To be completed by students
// Revision History
// -----------------------------------------------------------
// Name            Date            Reason
***********************************************************************/
#define _CRT_SECURE_NO_WARNINGS
#include <cstdio>
#include <cstring>
#include "File.h"

namespace sdds {
	FILE* fptr;

	// openFile function
	bool openFile(const char filename[]) {
		fptr = fopen(filename, "r");
		return fptr != NULL;
	}

	// noOfRecords function
	int noOfRecords() {
		int noOfRecs = 0;
		char ch;
		while (fscanf(fptr, "%c", &ch) == 1) {
			noOfRecs += (ch == '\n');
		}
		rewind(fptr);
		return noOfRecs;
	}

	// clsoeFile function
	void closeFile() {
		if (fptr) fclose(fptr);
	}
	//TODO: read functions go here
	bool read(int& employeeNum) {
		if (fscanf(fptr, "%d,", &employeeNum) == 1) {
			return true;
		}
		return false;
	}
	bool read(double& salary) {
		if (fscanf(fptr, "%lf,", &salary) == 1) {
			return true;
		}
		return false;
	}
	bool read(char*& employeeName) {
		char name[128];
		if (fscanf(fptr, "%127[^,\n]\n", name) == 1) {
			employeeName = new char[strlen(name) + 1];
			strcpy(employeeName, name);
			return true;
		}
		return false;
	}
}