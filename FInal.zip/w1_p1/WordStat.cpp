/*
Workshop - 1 Part - 1
Name : Kavya Bhavinkumar Shah
E-mail : kbshah6@mysesneca.ca
Section : ZCC
Student number : 140055229
*/
#include <iostream>
#include "Word.h"
using namespace sdds;
using namespace std;
int main() {
	char filename[256];
	programTitle();
	cout << "Enter filename: ";
	cin >> filename;
	wordStats(filename);
	return 0;
}